This board is an awesome ESP32 based adventure robot! We have a full tutorial on our website, as well as on our youtube channel, check it out! 

https://www.anyonecanbuildrobots.com/post/the-esp32-voyager-the-ultimate-open-source-esp32-adventure-robot

https://www.youtube.com/watch?v=Caz6NBKXSlM            
How to use：

At editor, Click the document icon on the topbar, via "Document" > "Open" > "EasyEDA Source", and select json file, then open it at the editor.



如何使用：

在编辑器顶部工具栏，点击“文档”图标，选择 “文档” > “打开” > “EasyEDA源码”，选择json文件打开即可。